<div class="container">
    <h2>Reporte</h2>
    <hr>

    <div class="well">
        <p id="date_filter" class="form-inline">
            <span id="date-label-from" class="date-label"><b>De:</b> </span><input
                    class="date_range_filter date form-control input-sm" placeholder="Fecha De" type="text" id="min"/>
            <span id="date-label-to" class="date-label"><b>A:</b> <input
                        class="date_range_filter date form-control input-sm" placeholder="Fecha A" type="text"
                        id="max"/>
        </p>
    </div>

    <div class="table-responsive">
        <table id="data-table" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>
                    No.
                </th>
                <th>
                    Datos del usuario
                </th>

                <th>
                    Fecha
                </th>
                <th>
                    A tiempo
                </th>
                <th>
                    Out Time
                </th>
                <th>
                    Work Hour
                </th>
                <th>
                    Over Time
                </th>
                <th>
                    Late Time
                </th>
                <th>
                    Early Out Time
                </th>
                <th>
                    In Location
                </th>
                <th>
                    Out Location
                </th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

</div><!--row-->

