<div class="container">
    <h2>Historial QR</h2>
    <hr>

    <div class="table-responsive">
        <table id="data-table" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>
                    No.
                </th>
                <th>
                    Datos Usuario
                </th>
                <th>
                    Código Qr
                </th>
                <th>
                    Acción
                </th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

</div><!--row-->


